// SourceGraph 브라우저 자동 로그인 — 영속 프로필로 세션을 얻어 쿠키를 반환 (sourcegraph-search.mjs가 필요할 때만 동적 import)
//
// 이 인스턴스는 ID/PW **API** 로그인(/-/sign-in 직접 POST)을 401로 거부한다(실측 2026-08-04).
// 반면 브라우저 폼 로그인은 정상 동작하므로, 설치된 Chromium을 띄워 폼 로그인을 자동 수행하고
// 세션을 영속 프로필(.claude/tmp/sg-profile)에 남긴다 → 다음 실행부터는 로그인 없이 쿠키만 재사용.
//
// 사용자 개입 0회가 목표다. 다만 로그인이 실패하면 **재시도하지 않고** 즉시 사유를 반환한다(계정 잠금 방지).

import { existsSync, readdirSync } from 'node:fs';
import { join } from 'node:path';

const MSPW = join(process.env.LOCALAPPDATA || '', 'ms-playwright');

// 시스템에 정식 설치된 Chromium 계열 브라우저(Edge/Chrome).
// ⚠ 실측(2026-08-12): 이 머신은 보안 에이전트가 ms-playwright 캐시의 Chromium을 차단한다
//    (chromium-1148/1208, headless_shell-1148/1208 4종 전부 about:blank조차 못 띄우고 행).
//    반면 정식 설치 브라우저는 정상 기동한다(msedge 15.1s / chrome 11.6s, 렌더 확인).
//    그래서 시스템 브라우저를 **먼저** 쓰고, 없을 때만 ms-playwright 캐시로 내려간다.
const SYSTEM_BROWSERS = [
  'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe',
  'C:\\Program Files\\Microsoft\\Edge\\Application\\msedge.exe',
  'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe',
  'C:\\Program Files (x86)\\Google\\Chrome\\Application\\chrome.exe',
];

// 실행할 브라우저 탐색. 우선순위: env 지정 > 시스템 설치 브라우저 > ms-playwright 캐시
export function findChromium() {
  if (process.env.SG_CHROMIUM_PATH && existsSync(process.env.SG_CHROMIUM_PATH)) return process.env.SG_CHROMIUM_PATH;

  for (const p of SYSTEM_BROWSERS) {
    if (existsSync(p)) return p;
  }

  if (!existsSync(MSPW)) return null;
  const dirs = readdirSync(MSPW).filter(d => d.startsWith('chromium-') && !d.includes('headless')).sort().reverse();
  for (const d of dirs) {
    for (const rel of ['chrome-win64\\chrome.exe', 'chrome-win\\chrome.exe']) {
      const p = join(MSPW, d, rel);
      if (existsSync(p)) return p;
    }
  }
  return null;
}

const log = (m) => process.stderr.write(`[sg-login] ${m}\n`);

// 반환: { ok:true, cookieHeader } | { ok:false, reason }
// manual=true 면 창을 띄우고 사용자가 직접 로그인할 때까지 대기(자동 폼 제출 안 함) — 성공하면 세션이 영속 프로필에 남는다.
export async function loginAndGetCookies({ url, id, pw, profileDir, headless = true, manual = false, timeoutMs = 20_000 }) {
  const exe = findChromium();
  if (!exe) return { ok: false, reason: 'Chromium 실행파일을 찾지 못함(ms-playwright 캐시 없음). SG_CHROMIUM_PATH로 지정 가능.' };

  let chromium;
  try { ({ chromium } = await import('playwright-core')); }
  catch (e) { return { ok: false, reason: `playwright-core 로드 실패: ${e.message} (.claude/tools에서 npm install 필요)` }; }

  // 프로필 잠금 행을 피하려 영속 프로필 대신 일반 실행(세션 재사용은 상위의 sg-session.json 쿠키 캐시가 담당).
  let browser;
  // 기동 상한: 이 머신은 보안 에이전트 스캔 때문에 기동이 느리다(헤드리스 Edge 실측 15.1s).
  // 창을 띄우는 헤드 모드는 더 느려 30초로는 부족했다(실측 2026-08-12 타임아웃) → 90초로 잡는다.
  const launchTimeout = headless ? 45_000 : 90_000;
  // Edge는 신규 프로필에서 첫 실행 안내를 띄우며 첫 내비게이션을 가로채 ERR_ABORTED를 낸다 → 관련 기능을 끈다.
  const launchOpts = {
    headless,
    args: [
      '--no-first-run', '--no-default-browser-check', '--no-service-autorun',
      '--disable-sync', '--disable-features=msEdgeFirstRunExperience,msFirstRunExperience,EdgeCollections',
    ],
    timeout: launchTimeout,
  };
  // findChromium()이 고른 실행파일을 먼저 쓴다. 정합 빌드 우선 시도는 하지 않는다 —
  // 이 머신에서 캐시 Chromium이 행에 걸려 30초를 그냥 버리기 때문이다(위 실측 주석 참조).
  try {
    log(`브라우저 기동: ${exe}`);
    browser = await chromium.launch({ ...launchOpts, executablePath: exe });
  } catch (e1) {
    try {
      log(`지정 실행파일 실패(${e1.message.split('\n')[0]}) → playwright 기본 빌드 폴백`);
      browser = await chromium.launch(launchOpts);
    } catch (e2) {
      return { ok: false, reason: `브라우저 기동 실패: ${e2.message}` };
    }
  }
  const ctx = await browser.newContext();

  try {
    const page = await ctx.newPage();

    // 1.5) 수동 모드: 창을 띄우고 사용자가 직접 로그인할 때까지 대기(최대 3분).
    // 로드가 느리거나 내비게이션 이벤트가 유실돼도 실패시키지 않는다 — 세션 쿠키(sgs) 등장을 2초 간격으로 폴링.
    if (manual) {
      log('브라우저 창에서 직접 로그인해 주세요(최대 3분 대기)...');
      // 신규 프로필의 첫 내비게이션이 ERR_ABORTED로 중단되는 사례가 있어 최대 3회 재시도한다(실측 2026-08-12).
      for (let i = 1; i <= 3; i++) {
        const err = await page.goto(`${url}/sign-in`, { waitUntil: 'commit', timeout: 60_000 }).then(() => null).catch(e => e);
        if (!err) break;
        log(`이동 실패(${i}/3): ${err.message.split('\n')[0]}`);
        await page.waitForTimeout(2_000);
      }
      log(`현재 주소: ${page.url()} — 빈 화면이면 주소창에 ${url}/sign-in 을 직접 입력해 주세요.`);
      const deadline = Date.now() + 180_000;
      while (Date.now() < deadline) {
        const c = await cookieHeader(ctx, url);
        if (c) {
          // 쿠키가 생겨도 로그인 직후 리다이렉트 전일 수 있으니 sign-in 화면을 벗어났는지도 확인
          const onSignIn = /\/sign-in/.test(page.url());
          if (!onSignIn) {
            log('수동 로그인 완료 — 세션이 프로필에 저장됨(이후 전자동)');
            return { ok: true, cookieHeader: c, reused: false };
          }
        }
        await new Promise(r => setTimeout(r, 2_000));
      }
      return { ok: false, reason: '3분 내 로그인이 감지되지 않음 — 창이 닫혔거나 로그인 미완료.' };
    }

    // 2) 폼 로그인 (1회만 — 실패해도 재시도하지 않음)
    if (!id || !pw) return { ok: false, reason: '세션이 없고 SourceGraph.md에 ID/PW도 없어 자동 로그인 불가.' };
    log('폼 로그인 페이지 이동...');
    if (!/\/sign-in/.test(page.url())) await page.goto(`${url}/sign-in`, { waitUntil: 'domcontentloaded', timeout: timeoutMs });

    const userSel = 'input[name="email"], input[name="username"], input[type="email"], input[autocomplete="username"]';
    const passSel = 'input[type="password"]';
    await page.waitForSelector(userSel, { timeout: 10_000 });
    await page.fill(userSel, id);
    await page.fill(passSel, pw);
    log('로그인 제출...');
    await page.click('button[type="submit"], input[type="submit"]');
    // 제출 후 리다이렉트 또는 오류 메시지 중 먼저 오는 쪽을 기다림(고정 대기 최소화)
    await Promise.race([
      page.waitForURL(u => !/\/sign-in/.test(typeof u === 'string' ? u : u.pathname + u.href), { timeout: timeoutMs }).catch(() => {}),
      page.waitForSelector('.alert-danger, [role="alert"]', { timeout: timeoutMs }).catch(() => {}),
    ]);
    await page.waitForTimeout(800);
    log(`제출 결과 URL: ${page.url()}`);

    if (/\/sign-in/.test(page.url())) {
      const err = (await page.locator('.alert-danger, [role="alert"], .e2e-sign-in-error').first().textContent().catch(() => '')) || '';
      return { ok: false, reason: `브라우저 폼 로그인 실패${err ? `: ${err.trim().slice(0, 200)}` : ' (자격증명 거부 또는 계정 잠금 의심)'}` };
    }
    const c = await cookieHeader(ctx, url);
    if (!c) return { ok: false, reason: '로그인은 된 듯하나 세션 쿠키를 얻지 못함.' };
    return { ok: true, cookieHeader: c, reused: false };
  } catch (e) {
    return { ok: false, reason: `자동 로그인 중 오류: ${e.message}` };
  } finally {
    // close가 프로토콜 불일치 등으로 행에 걸릴 수 있음 → 5초 상한(안 닫혀도 프로세스 종료 시 정리됨)
    await Promise.race([browser.close().catch(() => {}), new Promise(r => setTimeout(r, 5_000))]);
  }
}

async function cookieHeader(ctx, url) {
  const cookies = await ctx.cookies(url);
  const wanted = cookies.filter(c => /^(sgs|sg-session)$/.test(c.name));
  if (!wanted.length) return '';
  return wanted.map(c => `${c.name}=${c.value}`).join('; ');
}
