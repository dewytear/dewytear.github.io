# dews-sourcegraph — Claude Code 스킬 설치 안내

비공개 SourceGraph 인스턴스를 Claude Code에서 검색할 수 있게 해주는 스킬입니다. 브라우저 폼 로그인을 1회 자동 수행하고 세션을 캐시해 재사용하므로, 쿠키를 손으로 복사할 필요가 없습니다.

## 구성물

```
.claude/
├─ skills/dews-sourcegraph/SKILL.md    ← 스킬 본체(Claude가 읽는 사용법)
└─ tools/
   ├─ sourcegraph-search.mjs           ← 검색 실행 도구
   ├─ sourcegraph-login.mjs            ← 브라우저 자동 로그인 헬퍼
   └─ package.json / package-lock.json ← 의존성(playwright-core 1.49.1)
SourceGraph.md.example                  ← 자격증명 템플릿
```

## 설치

도구 경로가 `.claude/tools/...` 프로젝트 루트 상대이므로, **Claude Code를 여는 프로젝트 루트**에 설치합니다.

1. `.claude` 폴더를 프로젝트 루트에 병합합니다(기존 `.claude`가 있으면 폴더째 합치기).
2. `SourceGraph.md.example`을 프로젝트 루트에 **`SourceGraph.md`로 복사**하고 자기 인스턴스 주소와 계정을 채웁니다.
   ```
   URL:https://<sourcegraph-호스트>/
   ID:(계정 ID)
   PW:(비밀번호)
   ```
   다른 위치에 두려면 `SG_CRED_FILE` 환경변수로 경로를 지정합니다.
3. 의존성을 설치합니다.
   ```
   cd .claude/tools
   npm install
   ```
4. 시스템에 Edge 또는 Chrome이 설치되어 있어야 합니다(자동 로그인이 정식 설치 브라우저를 사용).
5. Claude Code를 재시작하면 스킬 목록에 `dews-sourcegraph`가 나타납니다.

## 사용

Claude에게 "소스그래프에서 ○○ 찾아줘", "전체 검색해줘"라고 하거나 `/dews-sourcegraph`를 호출합니다. 터미널에서 직접 실행할 수도 있습니다.

```
node --no-warnings .claude/tools/sourcegraph-search.mjs --query "myFunction file:\.java$ count:30" --max 20
```

## 주의

- **`SourceGraph.md`와 `.claude/tmp/`(세션 캐시)는 git에 커밋하지 마세요.** `.gitignore`에 추가합니다.
  ```
  SourceGraph.md
  .claude/tmp/
  ```
- 로그인이 실패하면 **재시도하지 마세요** — 연속 실패는 계정 일시잠금을 유발합니다. 도구가 출력하는 서버 메시지를 확인하고 자격증명을 고친 뒤 다시 시도합니다.
- 검색 결과는 사내 코드입니다. 외부 서비스로 내보내지 않습니다.
- 이 패키지에는 계정 정보가 들어 있지 않습니다. 인스턴스 주소와 계정은 각 조직에서 발급받아 채우세요.

## 문제 해결

| 증상 | 조치 |
|------|------|
| `playwright-core` 못 찾음 | `.claude/tools`에서 `npm install` 재실행 |
| 브라우저가 안 뜨거나 멈춤 | 시스템 Edge/Chrome 설치 확인. 보안 에이전트가 캐시 Chromium을 막는 환경이면 `SG_CHROMIUM_PATH`로 브라우저 경로 지정 |
| `자격증명 파일 없음` | 프로젝트 루트에 `SourceGraph.md`가 있는지, 또는 `SG_CRED_FILE` 경로가 맞는지 확인 |
| `User or password was incorrect` | `SourceGraph.md`의 ID/PW 확인 |
| `locked out` | 일시잠금 — 잠시 대기 후 시도 |
| 로그인 창을 직접 보고 싶음 | `SG_HEADED=1` 환경변수 + `--login` 옵션 |

## 라이선스·범위

스킬 문서와 도구는 특정 조직 정보를 담지 않은 일반화 버전입니다. 인스턴스 주소·계정·조직 고유 검색 예시는 각자 환경에 맞게 채워 쓰세요.
