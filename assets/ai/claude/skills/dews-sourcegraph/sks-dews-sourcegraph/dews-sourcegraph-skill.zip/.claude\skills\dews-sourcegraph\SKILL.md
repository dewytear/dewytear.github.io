---
name: dews-sourcegraph
description: 사내 SourceGraph 인스턴스로 조직 전체 코드를 검색 — 로컬 워크스페이스에 선례가 없거나 원본 코드의 소재를 확인해야 할 때 검색 범위를 넓히는 에스컬레이션. "전체 검색", "소스그래프", "다른 프로젝트 사례", 로컬에 없는 repo 조회 신호에.
---

# dews-sourcegraph — 조직 전체 코드 검색

> 자격증명 = 프로젝트 루트의 `SourceGraph.md`(URL/ID/PW) · 실행 도구 = `.claude/tools/sourcegraph-search.mjs`.

비공개 SourceGraph 인스턴스는 익명 접근이 막혀 있어 일반 웹 조회 도구로는 검색이 되지 않는다. 이 스킬은 브라우저 폼 로그인을 1회 자동 수행해 세션을 확보하고, 그 세션을 캐시해 재사용한다. 사람이 쿠키를 복사할 일이 없다.

## 언제 (로컬 우선 원칙)

**먼저 로컬 워크스페이스를 탐색한다.** 자기 저장소에서 선례를 찾지 못했을 때만 조직 전체로 넓힌다.

1. 로컬에 같은 유형의 선례가 없을 때(다른 팀·다른 프로젝트의 실사용례 검색).
2. 파생본만 로컬에 있고 원본이 어느 저장소에 있는지 확인해야 할 때.
3. 공통 라이브러리의 내부 구현·호출처를 봐야 할 때.

## 실행

```
node --no-warnings .claude/tools/sourcegraph-search.mjs --query "<쿼리>" [--max 20] [--pattern standard|literal|regexp] [--json]
```

인증 실패 시 도구가 원인과 해결책을 출력한다. **그 메시지를 사용자에게 그대로 전달하고 재시도하지 않는다** — 비밀번호 로그인을 반복하면 계정이 일시 잠금될 수 있다.

### 인증 흐름 (개입 0회)

1. 캐시된 세션(`.claude/tmp/sg-session.json`)이 있으면 그대로 검색한다(브라우저를 띄우지 않는다).
2. 세션이 없거나 검색이 401이면 → 시스템에 설치된 Edge/Chrome으로 **폼 로그인 1회** → 얻은 세션으로 검색을 이어서 수행 → 쿠키 캐시 저장.
3. 이후 세션이 살아 있는 동안 로그인 없이 재사용한다.

- 자격증명은 `SourceGraph.md`의 `ID:`/`PW:`. 도구는 이 파일을 **읽기만** 한다.
- 수동 우회가 필요하면 `COOKIE:sgs=...` 라인(또는 env `SRC_SESSION_COOKIE`)이 최우선으로 쓰인다.
- `--login`으로 창을 띄워 직접 로그인할 수도 있다. 창을 눈으로 보려면 `SG_HEADED=1`.
- 브라우저 자동화는 `playwright-core`(Node 18 호환 1.49.1)가 **정식 설치된 Edge/Chrome**을 `executablePath`로 구동한다. 영속 프로필은 쓰지 않는다(세션 재사용은 쿠키 캐시가 담당 — 프로필 잠금 회피).
- 보안 에이전트가 `ms-playwright` 캐시 Chromium을 차단하는 환경이 있다. 그래서 탐색 우선순위는 `SG_CHROMIUM_PATH` env > 시스템 Edge/Chrome > 캐시 Chromium이다.

> 인스턴스 설정에 따라 ID/PW **API** 로그인(`/-/sign-in` 직접 POST)이 거부될 수 있어, 브라우저 폼 로그인을 정식 경로로 삼는다. 또 비공개 인스턴스는 API 요청에 `X-Requested-With` 헤더를 요구하는 경우가 있다.
>
> **로그인 실패 시 재시도 금지.** 서버 메시지를 사용자에게 전달한다(`User or password was incorrect` = 자격증명 불일치 → `SourceGraph.md` 갱신, `locked out` = 일시잠금 → 대기).
>
> 액세스 토큰(`sgp_...`) 방식은 기본적으로 쓰지 않는다. 도구도 토큰을 읽지 않는다.

## 쿼리 문법 요약 (Sourcegraph 표준)

| 필터 | 예 | 의미 |
|---|---|---|
| (본문) | `myFunction` | 코드 내용 검색(standard = 스마트 리터럴) |
| `repo:` | `repo:my-service` | repo 이름 패턴 한정 |
| `file:` | `file:\.java$` · `file:mapper/` | 파일 경로 정규식 |
| `lang:` | `lang:java` | 언어 한정 |
| `count:` | `count:50` · `count:all` | 서버측 결과 상한 |
| `type:` | `type:symbol` · `type:path` | 매치 종류 |
| `-` 제외 | `-repo:test` `-file:bin/` | 부정 필터 |

- 정규식이 필요하면 `--pattern regexp`.
- 빌드 산출물 노이즈 제거: `-file:bin/ -file:target/` 병행 권장.

## 결과 사용법

- 결과 행은 `repo │ 파일:라인 │ 스니펫` 형식이다. 선례 근거로 남길 때는 **`[SG {repo}/{파일}:{라인} → 재현할 패턴]`** 형태로 기록한다(로컬 선례의 `파일:라인` 근거와 동급으로 취급).
- 원문 전체가 필요하면 그 repo가 로컬에 있는지 먼저 확인하고, 없으면 사용자에게 클론 여부를 묻는다(이 스킬은 검색·발췌까지만).

## 보안

- `SourceGraph.md`의 자격증명·쿠키와 검색 결과(사내 코드)를 **외부 서비스로 내보내지 않는다**(웹 검색·공개 페이지 게시 등).
- 도구는 `SourceGraph.md`를 읽기만 한다. `COOKIE:` 추가는 사용자가 직접 한다.
- `SourceGraph.md`와 `.claude/tmp/`(세션 캐시)는 **git에 커밋하지 않는다**(.gitignore 등록 필수).
