#!/usr/bin/env node
// 사내 SourceGraph 인스턴스 전체 코드 검색 CLI — 로컬에 선례가 없을 때 검색 범위를 조직 전체로 넓히는 도구 (dews-sourcegraph 스킬의 실행 도구)
//
// 사용법:
//   node .claude/tools/sourcegraph-search.mjs --query "myFunction count:20" [--max 20] [--pattern standard|literal|regexp] [--json]
//   (--query 생략 시 첫 비-플래그 인자를 쿼리로 사용)
//
// 자격증명: 프로젝트 루트의 SourceGraph.md(또는 env SG_CRED_FILE 로 지정한 경로) 의 URL:/ID:/PW:(+선택 COOKIE:) 라인을 읽기만 한다(이 스크립트는 그 파일을 수정하지 않음).
//
// 인증은 **전자동**이다(사용자 개입 0회):
//   ① 캐시된 세션 쿠키(.claude/tmp/sg-session.json)로 검색 시도
//   ② 세션이 없거나 401이면 → 설치된 Chromium(playwright-core)으로 **폼 로그인 1회 자동 수행**
//      → 얻은 세션으로 검색을 이어서 수행하고, 쿠키를 sg-session.json에 저장(다음 실행부터 재사용)
//   (수동 지정이 필요하면 env SRC_SESSION_COOKIE 또는 SourceGraph.md 의 COOKIE: 라인이 최우선)
//   (한 번 로그인하면 이후 실행은 캐시된 쿠키 경로로 수 초 내에 응답한다)
//
// ⚠ 인스턴스 설정에 따라 ID/PW **API** 로그인(/-/sign-in 직접 POST)이 401로 거부될 수 있다.
//    그래서 브라우저 폼 로그인(Chromium 자동화)이 정식 경로다. 로그인 실패 시 **재시도하지 않는다**(계정 잠금 방지).
// ※ 액세스 토큰 방식은 사용자 지시로 쓰지 않는다(브라우저 세션만 사용).
//
// ⚠ 비공개 인스턴스는 익명 접근이 401이고 API 요청에 X-Requested-With 헤더를 요구할 수 있다(일반 HTTP fetch 도구로는 조회 불가).
//
// 종료코드: 0=성공(0건 포함) / 1=사용법 / 2=인증 실패 / 3=네트워크(사내망 의심) / 4=서버 오류

import { readFileSync, writeFileSync, existsSync, mkdirSync } from 'node:fs';
import { join, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';

const CRED_FILE = process.env.SG_CRED_FILE || join(process.cwd(), 'SourceGraph.md');
const TOOLS_DIR = dirname(fileURLToPath(import.meta.url));
const TMP_DIR = join(TOOLS_DIR, '..', 'tmp');
const SESSION_FILE = join(TMP_DIR, 'sg-session.json');
const PROFILE_DIR = join(TMP_DIR, 'sg-profile');
// Sourcegraph 웹앱이 자기 XHR에 붙이는 헤더값 — 비면 CSRF 방지로 인증이 무시된다.
const XRW = { 'X-Requested-With': 'Sourcegraph' };
const TIMEOUT_MS = 30_000;

// ---------- 인자 ----------
function parseArgs(argv) {
  const a = { query: '', max: 20, pattern: 'standard', json: false, login: false };
  for (let i = 0; i < argv.length; i++) {
    const v = argv[i];
    if (v === '--query') a.query = argv[++i] ?? '';
    else if (v === '--max') a.max = Math.max(1, parseInt(argv[++i], 10) || 20);
    else if (v === '--pattern') a.pattern = argv[++i] ?? 'standard';
    else if (v === '--json') a.json = true;
    else if (v === '--login') a.login = true; // 창을 띄워 사용자가 직접 1회 로그인(세션은 프로필에 영속)
    else if (!v.startsWith('--') && !a.query) a.query = v;
  }
  return a;
}

// ---------- 자격증명(읽기 전용) ----------
function readCreds() {
  if (!existsSync(CRED_FILE)) fail(1, `자격증명 파일 없음: ${CRED_FILE} (URL:/ID:/PW: 라인 필요)`);
  const text = readFileSync(CRED_FILE, 'utf8').replace(/^\uFEFF/, '');
  const pick = (key) => {
    const m = text.match(new RegExp(`^${key}\\s*:\\s*(.+)$`, 'mi'));
    return m ? m[1].trim().replace(/\r$/, '') : '';
  };
  const creds = {
    url: pick('URL').replace(/\/+$/, ''),
    id: pick('ID'), pw: pick('PW'),
    cookie: process.env.SRC_SESSION_COOKIE || pick('COOKIE'),
  };
  if (!creds.url) fail(1, `자격증명 파일에 URL: 라인이 없음: ${CRED_FILE}`);
  return creds;
}

// ---------- 공통 ----------
function fail(code, msg) {
  process.stderr.write(`[sg][오류] ${msg}\n`);
  process.exit(code);
}

async function req(url, opts = {}) {
  try {
    return await fetch(url, { ...opts, signal: AbortSignal.timeout(TIMEOUT_MS), headers: { ...XRW, ...(opts.headers || {}) } });
  } catch (e) {
    const cause = e?.cause?.code || e?.name || '';
    fail(3, `네트워크 실패(${cause}): ${url}\n  → 사내망(VPN/사무실망) 미접속이거나 인스턴스 다운 의심. 브라우저로 접속 확인 후 재시도.`);
  }
}

function authFailMsg(status, via) {
  const head = `인증 실패(HTTP ${status}, 방식=${via}) — ${CRED_FILE} 확인 필요.`;
  if (via === 'password') {
    return `${head}\n  → 이 인스턴스는 ID/PW API 로그인이 거부된다(실측). 과거 성공 경로는 **브라우저 로그인 세션**이다.\n    브라우저로 로그인한 뒤 세션 쿠키를 ${CRED_FILE} 에 한 줄 추가할 것:\n      COOKIE:sgs=xxxxx   ← DevTools(F12) → Application → Cookies → (인스턴스 호스트) → sgs 값\n    ⚠ 실패한 비밀번호 로그인을 반복하지 말 것(계정 일시잠금 유발).`;
  }
  return `${head}\n  → 브라우저 세션이 만료됐을 가능성이 큼. 브라우저에서 다시 로그인해 sgs 쿠키 값을 COOKIE: 라인에 새로 복사할 것.`;
}

// ---------- 세션 캐시 ----------
function readCachedSession() {
  try {
    const s = JSON.parse(readFileSync(SESSION_FILE, 'utf8'));
    return s.cookieHeader || '';
  } catch { return ''; }
}
function writeCachedSession(cookieHeader) {
  try {
    mkdirSync(TMP_DIR, { recursive: true });
    writeFileSync(SESSION_FILE, JSON.stringify({ cookieHeader, savedAt: new Date().toISOString() }, null, 2), 'utf8');
  } catch { /* 캐시 실패는 치명 아님 */ }
}

// ---------- 인증 ----------
// 수동 지정(COOKIE:/env) > 캐시된 세션 > (검색이 401이면) 브라우저 자동 로그인
function initialAuth(creds) {
  if (creds.cookie) {
    const c = creds.cookie.includes('=') ? creds.cookie : `sgs=${creds.cookie}`;
    return { headers: { Cookie: c }, via: 'cookie(수동)' };
  }
  const cached = readCachedSession();
  if (cached) return { headers: { Cookie: cached }, via: 'cookie(캐시)' };
  return null;
}

// 브라우저 폼 로그인 1회 — 성공 시 세션을 캐시에 저장하고 인증정보 반환. manual=true면 사용자가 창에서 직접 로그인.
async function browserLogin(creds, manual = false) {
  let mod;
  try { mod = await import('./sourcegraph-login.mjs'); }
  catch (e) { fail(2, `브라우저 로그인 모듈 로드 실패: ${e.message}`); }

  process.stderr.write(manual ? '[sg] 수동 로그인 모드 — 창에서 직접 로그인해 주세요\n' : '[sg] 세션 없음/만료 → 브라우저 자동 로그인 시도(1회)\n');
  const r = await mod.loginAndGetCookies({
    url: creds.url, id: creds.id, pw: creds.pw, profileDir: PROFILE_DIR,
    headless: manual ? false : process.env.SG_HEADED !== '1',
    manual,
  });
  if (!r.ok) {
    fail(2, `자동 로그인 실패 — ${r.reason}\n  → 자격증명(${CRED_FILE})이 유효한지 확인 필요. **반복 시도 금지**(계정 일시잠금 유발).\n    수동 우회: 브라우저 로그인 후 DevTools의 sgs 쿠키를 COOKIE: 라인에 넣으면 그 값이 최우선으로 쓰인다.`);
  }
  writeCachedSession(r.cookieHeader);
  process.stderr.write(`[sg] 로그인 ${r.reused ? '불필요(프로필 세션 재사용)' : '성공'} — 세션 캐시 갱신\n`);
  return { headers: { Cookie: r.cookieHeader }, via: r.reused ? 'cookie(프로필)' : 'browser-login' };
}

// ---------- 검색 (SSE stream API) ----------
async function search(creds, auth, { query, pattern, max }, { allowRelogin = true } = {}) {
  // ⚠ 실측(2026-08-12): 이 인스턴스는 URL 파라미터 `&patternType=`을 **무시한다**.
  //    정규식이 리터럴로 처리돼 조용히 0건이 나온다(에러도 alert도 없어 오탐 판정으로 이어짐).
  //    확인: `htmlControl-[0-9]+` → 파라미터 방식 0건 / 쿼리내 `patternType:regexp` 방식 500건.
  //    그래서 patternType은 **쿼리 문자열 안에** 넣는다.
  const effectiveQuery = pattern !== 'standard' && !/(^|\s)patternType:/.test(query)
    ? `patternType:${pattern} ${query}`
    : query;
  const url = `${creds.url}/.api/search/stream?q=${encodeURIComponent(effectiveQuery)}&display=${max}`;
  const res = await req(url, { headers: { ...auth.headers, Accept: 'text/event-stream' } });
  if (res.status === 401 || res.status === 403) {
    // 세션 만료 — 브라우저 자동 재로그인 1회 후 이어서 검색(재귀는 1단계로 제한)
    if (allowRelogin && !creds.cookie) {
      const fresh = await browserLogin(creds);
      return search(creds, fresh, { query, pattern, max }, { allowRelogin: false });
    }
    fail(2, authFailMsg(res.status, auth.via));
  }
  if (res.status >= 500) fail(4, `인스턴스 장애(HTTP ${res.status}) — 잠시 후 재시도.`);
  if (!res.ok) fail(4, `검색 응답 이상(HTTP ${res.status}).`);

  const matches = [];
  let alert = null, progress = null;
  let buf = '';
  for await (const chunk of res.body) {
    buf += Buffer.from(chunk).toString('utf8');
    let idx;
    while ((idx = buf.indexOf('\n\n')) !== -1) {
      const block = buf.slice(0, idx); buf = buf.slice(idx + 2);
      const ev = (block.match(/^event:\s*(.+)$/m) || [])[1]?.trim();
      const dataLine = block.split('\n').filter(l => l.startsWith('data:')).map(l => l.slice(5).trim()).join('');
      if (!ev || !dataLine) continue;
      try {
        const data = JSON.parse(dataLine);
        if (ev === 'matches') matches.push(...data);
        else if (ev === 'alert') alert = data;
        else if (ev === 'progress') progress = data;
        else if (ev === 'error') fail(4, `검색 스트림 오류: ${JSON.stringify(data)}`);
      } catch { /* 파싱 불가 이벤트는 스킵 */ }
    }
  }
  return { matches: matches.slice(0, max), alert, progress, auth };
}

// ---------- 출력 ----------
function flatten(m) {
  const repo = m.repository || '';
  if (m.type === 'content') {
    const rows = [];
    for (const c of m.chunkMatches || []) {
      const base = c.contentStart?.line ?? 0;
      const lines = (c.content || '').split('\n');
      const seen = new Set();
      for (const r of c.ranges || []) {
        const ln = r.start?.line ?? base;
        if (seen.has(ln)) continue; seen.add(ln);
        rows.push({ repo, path: m.path, line: ln + 1, snippet: (lines[ln - base] || '').trim() });
      }
    }
    for (const l of m.lineMatches || []) rows.push({ repo, path: m.path, line: (l.lineNumber ?? 0) + 1, snippet: (l.line || '').trim() });
    return rows.length ? rows : [{ repo, path: m.path, line: null, snippet: '' }];
  }
  if (m.type === 'path') return [{ repo, path: m.path, line: null, snippet: '(파일명 매치)' }];
  if (m.type === 'repo') return [{ repo, path: '', line: null, snippet: '(repo 매치)' }];
  if (m.type === 'symbol') return (m.symbols || []).map(s => ({ repo, path: m.path, line: s.line ?? null, snippet: `(symbol) ${s.name}` }));
  return [];
}

// ---------- main ----------
const args = parseArgs(process.argv.slice(2));
if (!args.login && !args.query) fail(1, '쿼리가 없음. 사용법: node sourcegraph-search.mjs --query "<sourcegraph 쿼리>" [--max N] [--pattern standard|literal|regexp] [--json] | --login(수동 1회 로그인)');

// 전역 워치독: 어떤 단계가 행에 걸려도 상한을 넘기지 않는다(수동 로그인은 4분, 그 외 120초)
// 수동 로그인은 [기동 최대 90s + 폴백 90s + 사용자 대기 180s]가 겹칠 수 있어 240s로는 부족했다(실측 2026-08-12).
const WATCHDOG_MS = args.login ? 420_000 : 120_000;
setTimeout(() => { process.stderr.write(`[sg][오류] 전역 워치독(${WATCHDOG_MS / 1000}s) 초과 — 마지막 단계 로그를 확인할 것.\n`); process.exit(3); }, WATCHDOG_MS).unref();

if (args.login) {
  const c = readCreds();
  await browserLogin(c, true);
  process.stdout.write('로그인 세션 저장 완료 — 이후 검색은 전자동으로 동작.\n');
  process.exit(0);
}

const creds = readCreds();
// 세션이 있으면 그대로 쓰고, 없으면 이 자리에서 자동 로그인. 검색 중 401이 나면 search()가 1회 재로그인 후 이어서 수행.
const auth = initialAuth(creds) || await browserLogin(creds);
const { matches, alert, progress, auth: usedAuth } = await search(creds, auth, args);
const rows = matches.flatMap(flatten).slice(0, args.max);
const via = usedAuth?.via || auth.via;

if (args.json) {
  process.stdout.write(JSON.stringify({ query: args.query, auth: via, count: rows.length, matchCount: progress?.matchCount ?? null, alert: alert?.title ?? null, results: rows }, null, 2) + '\n');
} else {
  if (alert) process.stderr.write(`[sg][안내] ${alert.title}${alert.description ? ' — ' + alert.description : ''}\n`);
  if (!rows.length) {
    process.stdout.write(`0건 — 쿼리를 넓혀볼 것(예: repo:/file: 필터 제거, patternType 변경). 쿼리: ${args.query}\n`);
  } else {
    for (const r of rows) process.stdout.write(`${r.repo} │ ${r.path}${r.line ? ':' + r.line : ''} │ ${r.snippet}\n`);
    const total = progress?.matchCount;
    process.stdout.write(`— ${rows.length}건 표시${total != null ? ` (서버 매치 ${total}건)` : ''}, 인증=${auth.via}\n`);
  }
}
